# Original source excerpts


Bounded static capture, not proof of complete source coverage or semantic correctness. Only original excerpts are source evidence; model reasons are diagnostics. Newly fetched bytes have their own capture time and hash.

Offsets use each excerpt's offset_unit; end is exclusive. PDF offsets refer to extracted page text, not PDF bytes. Original bytes and hashes are retained in the capture manifest.


## Capture limitations


[{"detail": "Scripts are not executed; rendered DOM, runtime network requests and unreferenced assets are not captured.", "kind": "static_capture_only"}, {"error_type": "ValueError", "kind": "fetch_failed", "reference_id": "ref-a94c25b7707df61b5f3aa589"}, {"error_type": "HTTPError", "kind": "fetch_failed", "reference_id": "ref-8fe89541e7486fe693fbea99"}]
