# Source attribution

The original **NEM Registration and Exemption List**, dated 13 October 2026, was created and published by the **Australian Energy Market Operator (AEMO)**. The workbook is retained unchanged for this assessment and must not be presented as our own data.

- [Original publisher page](https://www.aemo.com.au/energy-systems/electricity/national-electricity-market-nem/participate-in-the-market/registration)
- [AEMO Copyright Permissions](https://www.aemo.com.au/privacy-and-legal-notices/copyright-permissions)

AEMO's notice permits use of its public material with accurate and appropriate attribution, subject to the stated exclusions. Permission was checked after the experiment; the frozen request's original unknown licence value remains intact. Our report and audit are separate from the original workbook.
