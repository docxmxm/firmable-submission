"""Read-only independent audit of the frozen holdout; never invokes a model."""
import hashlib
import json
import sys
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
sys.path.insert(0, str(PROJECT))
from firmable_runtime.execution import discover
from firmable_runtime.runtime import runtime_fingerprint


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def valid_abn(value):
    digits = "".join(c for c in str(value) if c.isdigit())
    if len(digits) != 11:
        return False
    numbers = [int(c) for c in digits]
    numbers[0] -= 1
    return sum(a * b for a, b in zip(numbers, [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19])) % 89 == 0


freeze = load(ROOT / "freeze.json")
selection = load(ROOT / "selection.json")
summary = load(ROOT / "trial/summary.json")
receipts = load(ROOT / "trial/provider-receipts.json")
labels = load(ROOT / "evaluation-labels.json")
source_id = selection["source_id"]
execution = ROOT / "trial/execution" / source_id
native = ROOT / "input/evidence/nem-registration-and-exemption-list.xlsx"
assert sha(native) == labels["native_sha256"]
assert runtime_fingerprint() == freeze["runtime_hash"]
changed = [name for name, expected in freeze["files_sha256"].items() if sha(PROJECT / name) != expected]
assert not changed
assert summary["status"] == "finished" and summary["integrity_end"]["unchanged"]
assert summary["model_calls"] == len(receipts) == 6
assert all(r["request_started"] and r["response_complete"] and r["outcome"] == "success" for r in receipts)
assert abs(sum(r["cost_usd"] for r in receipts) - summary["reported_cost_usd"]) < 1e-12
assert labels["frozen_at_utc"] < summary["results"][0]["started_at"]

book = openpyxl.load_workbook(native, read_only=True, data_only=True)
regenerated = []
sheets = []
for sheet in book:
    active_columns = []
    nonempty_count = 0
    multiple_actor_header = False
    for row_number, cells in enumerate(sheet.iter_rows(values_only=True), 1):
        if not any(v is not None and str(v).strip() for v in cells):
            continue
        nonempty_count += 1
        header = [i for i, v in enumerate(cells) if isinstance(v, str) and v.strip() == "ABN"]
        if header:
            active_columns = header
            multiple_actor_header |= len(header) > 1
            continue
        for column in active_columns:
            value = cells[column] if column < len(cells) else None
            if value is not None and valid_abn(value):
                regenerated.append({"sheet": sheet.title, "row": row_number, "column": column + 1,
                    "source_header": "ABN", "source_value": value, "field": "entity.abn",
                    "expected": "".join(c for c in str(value) if c.isdigit()),
                    "label_basis": "Explicit ABN column and checksum; source agreement, not independent ownership gold"})
    sheets.append({"sheet": sheet.title, "nonempty_rows_including_headers": nonempty_count,
                   "multiple_actor_abn_columns": multiple_actor_header})
assert regenerated == labels["labels"], "Frozen source-value opportunities did not reproduce"

tables, _, _, _ = discover(ROOT / "input/evidence", source_id)
response_path = next(execution.glob("artifacts/response-*.json"))
response = load(response_path)["config"]
selected = response["selected_table_ids"]
unsupported = [{"table_id": i, "sheet": tables[i]["sheet"], "status": tables[i]["status"]}
               for i in selected if tables[i]["status"] != "table"]
assert len(unsupported) == 2
assert not (execution / "artifacts/final-config.json").exists()
assert not (execution / "approval.json").exists()
assert not (execution / "observations.jsonl").exists()
assert summary["results"][0]["error"]["message"] == "Selected table is not a discovered native table"

result = {
    "status": "failed_before_candidate_generation", "runtime_hash": runtime_fingerprint(),
    "frozen_code_files_unchanged": len(freeze["files_sha256"]), "native_sha256": sha(native),
    "native_sheet_count": len(tables), "readable_table_count": sum(t["status"] == "table" for t in tables),
    "reader_tables": [{"table_id": i, "sheet": t["sheet"], "status": t["status"],
                       "reader_record_count": len(t.get("records", []))} for i, t in enumerate(tables)],
    "independent_workbook_inventory": sheets, "model_selected_table_ids": selected,
    "unsupported_selected_business_tables": unsupported,
    "source_value_opportunities_reproduced": len(regenerated),
    "evaluation_scope": "ABN cell agreement opportunities, not legal-name/ownership gold; multiple actor columns are not one canonical entity.",
    "scope_addendum_is_post_run": True,
    "new_model_calls": summary["model_calls"], "input_tokens": summary["input_tokens"],
    "output_tokens": summary["output_tokens"], "total_tokens": summary["input_tokens"] + summary["output_tokens"],
    "reported_cost_usd": summary["reported_cost_usd"], "wall_seconds": summary["wall_seconds"],
    "all_six_responses_known_and_complete": True, "unknown_outcomes": 0, "budget_stop": summary["stop_reason"],
    "validated_configs": 0, "approvals": 0, "formal_observations": 0,
    "semantic_precision": None, "semantic_recall": None, "raw_output_fidelity": None,
    "metric_limitation": "No candidate config or extracted output exists; semantic and output raw-fidelity scores are N/A, not zero-error or successful abstention.",
    "generalisation_pass": False, "no_hand_mapping_or_code_edits": True,
}
(ROOT / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in ["reader_tables", "independent_workbook_inventory"]}, indent=2))
